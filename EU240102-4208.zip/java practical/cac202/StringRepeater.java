import java.util.Scanner;

public class StringRepeater {

    // Method to repeat a string n times
    public static String repeatString(String text, int n) {
        if (n < 0) {
            return "Invalid repetition count";
        }

        String result = "";

        for (int i = 0; i < n; i++) {
            result += text;
        }

        return result;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter a string: ");
        String text = scanner.nextLine();

        System.out.print("Enter number of repetitions: ");
        int n = scanner.nextInt();

        String output = repeatString(text, n);

        System.out.println("Result: " + output);

        scanner.close();
    }
}
