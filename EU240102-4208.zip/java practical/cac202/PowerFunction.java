import java.util.Scanner;

public class PowerFunction {

    // Recursive method to compute base^exponent
    public static long power(int base, int exponent) {
        if (exponent == 0) {
            return 1; // anything^0 = 1
        }

        return base * power(base, exponent - 1);
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter base: ");
        int base = scanner.nextInt();

        System.out.print("Enter exponent: ");
        int exponent = scanner.nextInt();

        long result = power(base, exponent);

        System.out.println(base + "^" + exponent + " = " + result);

        scanner.close();
    }
}