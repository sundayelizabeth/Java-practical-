import java.util.Scanner;

class Student {
    String name;
    int age;
    double grade;

    // Method to display student details
    public void display() {
        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
        System.out.println("Grade: " + grade);
        System.out.println("-------------------");
    }
}

public class StudentManager {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter number of students: ");
        int n = scanner.nextInt();
        scanner.nextLine(); // consume newline

        Student[] students = new Student[n];

        // Input student details
        for (int i = 0; i < n; i++) {
            students[i] = new Student();

            System.out.println("Enter details for student " + (i + 1));

            System.out.print("Name: ");
            students[i].name = scanner.nextLine();

            System.out.print("Age: ");
            students[i].age = scanner.nextInt();

            System.out.print("Grade: ");
            students[i].grade = scanner.nextDouble();
            scanner.nextLine(); // consume newline
        }

        // Output student details
        System.out.println("\n--- Student List ---");
        for (int i = 0; i < n; i++) {
            students[i].display();
        }

        scanner.close();
    }
}