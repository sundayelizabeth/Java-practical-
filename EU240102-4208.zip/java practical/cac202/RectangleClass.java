import java.util.Scanner;

class Rectangle {
    double width;
    double height;

    // Method to calculate area
    public double area() {
        return width * height;
    }

    // Method to calculate perimeter
    public double perimeter() {
        return 2 * (width + height);
    }
}

public class RectangleClass {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        Rectangle rect = new Rectangle();

        System.out.print("Enter width: ");
        rect.width = scanner.nextDouble();

        System.out.print("Enter height: ");
        rect.height = scanner.nextDouble();

        System.out.println("Area: " + rect.area());
        System.out.println("Perimeter: " + rect.perimeter());

        scanner.close();
    }
}