import java.util.Scanner;
public class week4 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter your score: ");

        int score = scanner.nextInt();
        if (score >= 90) {
            System.out.println("A");
        } else if (score >= 80) {
            System.out.println("B");
        } else if (score >= 70) {
            System.out.println("C");
        } else if (score >= 60) {
            System.out.println("D");
        } else {
            System.out.println("F");
        }

        scanner.nextLine();
        
        Scanner scanner2 = new Scanner(System.in);
        System.out.print("Enter your day: ");
        String day = scanner2.nextLine();
    switch (day) {
        case "Monday":
            System.out.println("Start of the week");
            break;
        case "Tuesday":
            System.out.println("Second day of the week");
            break;
        case "Wednesday":
            System.out.println("Midweek");
            break;
        case "Thursday":
            System.out.println("Almost there");
            break;
        case "Friday":
            System.out.println("End of the week");
            break;
        default:
            System.out.println("Weekend");
            break;
    }
    scanner.close();
    scanner2.close();
  }
}
