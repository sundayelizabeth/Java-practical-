import java.util.Scanner;

public class SumOfDigits {

    // Recursive method to sum digits
    public static int sumDigits(int n) {
        if (n == 0) {
            return 0;
        }
        return (n % 10) + sumDigits(n / 10);
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter a number: ");
        int num = scanner.nextInt();

        // Handle negative numbers
        num = Math.abs(num);

        int result = sumDigits(num);

        System.out.println("Sum of digits: " + result);

        scanner.close();
    }
}