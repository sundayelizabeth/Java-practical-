public class SelectionDemo {
    public static void main(String[] args) {
        int score = 85;
        if (score >= 90) {
            System.out.println("Grade: A");
        } else if (score >=80) {
            System.out.println("Grade: B");
        } else {
            System.out.println("Grade: C");
        }

        String day = "Monday";
        switch (day) {
            case "monday":
                System.out.println("Start of the week");
                break;
            default:
                System.out.println("other day");    
        }
    }
}
