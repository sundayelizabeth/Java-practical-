public class stringDemo {
    public static void main(String[] args) {
        String str = "Hello, java!";
        System.out.println("length: " + str.length());
        System.out.println("First char: " + str.charAt(0));  
        System.out.println("Substring: " + str.substring(7, 11));
        System.out.println("Uppercase: " + str.toUpperCase());
        System.out.println("Uppercase: " + str.toLowerCase());
    }      
}