import java.util.Scanner;

public class palindromecheck {
    public static void main(String[] args) {
        
        Scanner input = new Scanner(System.in);
        System.out.print("Enter a string: "); 
        String text = input.nextLine();
        
        String reversed = "";

        for (int i = text.length() - 1; i >= 0; i--) {
            reversed += text.charAt(i);
        }
        if (text.equalsIgnoreCase(reversed)) {
            System.out.println("The string is a pelindrome.");
        } else {
            System.out.println("The string is not a palindrom.");
        }
        input.close();
     }
}
