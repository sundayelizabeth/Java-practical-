class Counter {
    // static variable shared by all objects
    static int count = 0;

    // constructor runs every time an object is created
    Counter() {
        count++;
    }

    // method to display count
    public static void showCount() {
        System.out.println("Total objects created: " + count);
    }
}

public class CounterClass {
    public static void main(String[] args) {

        Counter c1 = new Counter();
        Counter c2 = new Counter();
        Counter c3 = new Counter();

        Counter.showCount();
    }
}