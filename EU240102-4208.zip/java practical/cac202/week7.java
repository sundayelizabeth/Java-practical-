public class week7 {
    public static void main(String[] args) {
        System.out.println("Factorial of 5: " + factorial(5));
    }
    
    public static int factorial(int n) {
        if (n == 0) {//Base case
            return 1;
        }
    return n* factorial (n-1); //Recursive case
    }

    
}

