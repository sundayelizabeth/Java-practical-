public class week8 {
    public static void main(String[] args) {
        int[] numbers = {1, 2, 3, 4, 5};
        System.out.println("Length element: " + numbers[0]);
        System.out.println("Length:" + numbers.length);

        //2D array
        int[][] matrix ={{1,2},{3,4}};
        System.out.println("Matrix element: " + matrix[1][0]);
        
        }
    
}
