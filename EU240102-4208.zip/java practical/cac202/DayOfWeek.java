import java.util.Scanner;
public class DayOfWeek {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        System.out.print("Enter day of the week: ");
        String day = input.nextLine();
        switch (day.toLowerCase()) {
            case "monday":
                System.out.println("Start of the week");
                break;
            case "tuesday":
                System.out.println("Second day of the week");
                break;
            case "wednesday":
                System.out.println("Midweek");
                break;
            case "thursday":
                System.out.println("Almost weekend");
                break;
            case "friday":
                System.out.println("Last day of the workweek");
                break;
            case "saturday":
            case "sunday":
                System.out.println("Weekend!");
                break;
            default:
                System.out.println("Invalid day of the week");
        }
        input.close();
    }
}
