import java.util.Scanner;

public class Fibonacci {

    // Recursive method to get nth Fibonacci number
    public static int fibonacci(int n) {
        if (n == 0) {
            return 0;
        }
        if (n == 1) {
            return 1;
        }
        return fibonacci(n - 1) + fibonacci(n - 2);
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter position (n): ");
        int n = scanner.nextInt();

        int result = fibonacci(n);

        System.out.println("Fibonacci number at position " + n + " is: " + result);

        scanner.close();
    }
}