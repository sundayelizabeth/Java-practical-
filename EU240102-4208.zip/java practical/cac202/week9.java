public class week9 {
    String name;
    int age;

    public void introduce() {
        System.out.println("I am " + name + " , " +age + " years old.");

    
    }

    public static void main( String [] ags ) {
        week9 student = new week9();
        student.name = "Teddy";
        student.age = 20;
        student.introduce();


    }
}    