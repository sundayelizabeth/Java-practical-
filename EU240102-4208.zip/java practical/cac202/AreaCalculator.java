import java.util.Scanner;

public class AreaCalculator {

    // Area of circle
    public static double area(double radius) {
        return Math.PI * radius * radius;
    }

    // Area of triangle
    public static double area(double base, double height) {
        return 0.5 * base * height;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Choose shape:");
        System.out.println("1. Circle");
        System.out.println("2. Triangle");
        System.out.print("Enter choice: ");
        int choice = scanner.nextInt();

        if (choice == 1) {
            System.out.print("Enter radius: ");
            double radius = scanner.nextDouble();

            double result = area(radius);
            System.out.println("Area of circle: " + result);

        } else if (choice == 2) {
            System.out.print("Enter base: ");
            double base = scanner.nextDouble();

            System.out.print("Enter height: ");
            double height = scanner.nextDouble();

            double result = area(base, height);
            System.out.println("Area of triangle: " + result);

        } else {
            System.out.println("Invalid choice.");
        }

        scanner.close();
    }
}