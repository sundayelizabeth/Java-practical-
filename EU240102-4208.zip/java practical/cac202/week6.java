public class week6 {
    public static void main(String[] args) {
        //For loop
        for (int i = 0; i < 5; i++); {

        } 
       
        
        //While loop
        int j =1;
        while (j <= 5) {
            System.out.println(j);
            j++;
        }
        
        //Do-while loop
        int k = 1;
        do {
            System.out.println("Do-while:"+k);
            k++;

        }while (k <= 5);
    
    }

}
    

