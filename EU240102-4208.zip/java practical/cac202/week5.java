public class week5 {
    public static void main(String[] args) {
        System.out.println("Max: " + max(10, 20));
        printMessages("Hello!");
    }
    public static int max(int a, int b) {
        return a > b ? a : b;
    }
    public static void printMessages(String message) {
        System.out.println(message);
    }
}
