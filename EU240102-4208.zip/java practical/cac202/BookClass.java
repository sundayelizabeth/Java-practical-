class Book {
    String title;
    String author;

    // Method to display book details
    public void displayDetails() {
        System.out.println("Book Title: " + title);
        System.out.println("Author: " + author);
    }
}

public class BookClass {
    public static void main(String[] args) {

        Book b1 = new Book();

        b1.title = "The Alchemist";
        b1.author = "Paulo Coelho";

        b1.displayDetails();
    }
}