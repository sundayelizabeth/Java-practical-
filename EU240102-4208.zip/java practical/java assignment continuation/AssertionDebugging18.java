// File: AssertionDebugging.java

import java.util.Scanner;

public class AssertionDebugging18 {

    // Method to calculate average
    public static double calculateAverage(int total, int count) {

        // Debugging assertion
        assert count > 0 : "Count must be greater than zero.";

        return (double) total / count;
    }

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        System.out.print("Enter total marks: ");
        int total = input.nextInt();

        System.out.print("Enter number of subjects: ");
        int count = input.nextInt();

        double average = calculateAverage(total, count);

        System.out.println("Average = " + average);

        input.close();
    }
}