import java.io.*;
import java.util.Scanner;

public class BinaryCounter19 {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        System.out.print("How many integers do you want to store? ");
        int count = input.nextInt();

        // Write integers to binary file
        try {
            DataOutputStream out = new DataOutputStream(
                    new FileOutputStream("numbers.dat"));

            System.out.println("Enter " + count + " integers:");

            for (int i = 0; i < count; i++) {
                int number = input.nextInt();
                out.writeInt(number);
            }

            out.close();
            System.out.println("\nNumbers written to binary file successfully.");

        } catch (IOException e) {
            System.out.println("Error writing to file.");
        }

        // Read integers from binary file
        try {
            DataInputStream in = new DataInputStream(
                    new FileInputStream("numbers.dat"));

            System.out.println("\nNumbers read from the binary file:");

            for (int i = 0; i < count; i++) {
                int number = in.readInt();
                System.out.println(number);
            }

            in.close();

        } catch (IOException e) {
            System.out.println("Error reading from file.");
        }

        input.close();
    }
}