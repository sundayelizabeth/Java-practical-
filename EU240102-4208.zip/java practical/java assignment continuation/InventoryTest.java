import java.util.Scanner;

class Item {
    private String name;
    private int quantity;

    public Item(String name, int quantity) {
        this.name = name;
        this.quantity = quantity;
    }

    public void addStock(int amount) {
        quantity += amount;
    }
    public void display() {
        System.out.println("Item: " + name);
        System.out.println("Quantity: " + quantity);
    }
}

public class InventoryTest {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter name: ");
        String name = input.nextLine();

          System.out.print("Enter quamtity: ");
          int quantity = input.nextInt();

          Item item = new Item(name, quantity);

          System.out.print("Enter stock to add: ");
          int add = input.nextInt();

          item.addStock(add);

          item.display();
    }
}
