// File: PolyMethod.java

class Shape {
    public double getArea() {
        return 0;
    }
}

class Circle extends Shape {
    double radius;

    Circle(double radius) {
        this.radius = radius;
    }

    @Override
    public double getArea() {
        return 3.14 * radius * radius;
    }
}

class Rectangle extends Shape {
    double length, width;

    Rectangle(double length, double width) {
        this.length = length;
        this.width = width;
    }

    @Override
    public double getArea() {
        return length * width;
    }
}

public class PolyMethod {

    // Polymorphic method
    public static void displayArea(Shape shape) {
        System.out.println("Area = " + shape.getArea());
    }

    public static void main(String[] args) {
        Shape circle = new Circle(7);
        Shape rectangle = new Rectangle(8, 5);

        System.out.println("Circle:");
        displayArea(circle);

        System.out.println("Rectangle:");
        displayArea(rectangle);
    }
}