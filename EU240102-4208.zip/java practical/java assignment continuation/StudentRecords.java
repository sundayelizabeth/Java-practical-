// File: StudentRecords.java

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class StudentRecords {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        try {
            // Write student records to a file
            FileWriter writer = new FileWriter("students.txt");

            System.out.print("Enter the number of students: ");
            int n = input.nextInt();
            input.nextLine(); // Consume newline

            for (int i = 1; i <= n; i++) {
                System.out.print("Enter student name: ");
                String name = input.nextLine();

                System.out.print("Enter student grade: ");
                String grade = input.nextLine();

                writer.write(name + " - " + grade + "\n");
            }

            writer.close();
            System.out.println("\nStudent records saved successfully.\n");

            // Read and display the records
            BufferedReader reader = new BufferedReader(new FileReader("students.txt"));

            String line;
            System.out.println("Student Records:");

            while ((line = reader.readLine()) != null) {
                System.out.println(line);
            }

            reader.close();

        } catch (IOException e) {
            System.out.println("Error: " + e.getMessage());
        }

        input.close();
    }
}