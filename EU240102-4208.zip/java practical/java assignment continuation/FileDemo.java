import java.io.*;
import java.util.Scanner;

public class FileDemo {
    public static void main(String[] args) {
        try(PrintWriter writer = new PrintWriter("output.txt")) {
            writer.println("Hello, java!");
        } catch (FileNotFoundException e) {
            System.out.println("Error:" + e.getMessage());
        }

        try(Scanner scanner = new Scanner(new File("output.txt"))) {
            while(scanner.hasNextLine()) {

                System.out.println(scanner.nextLine());
            }
        } catch (FileNotFoundException e) {
            System.out.println("Error:" + e.getMessage());
        }
    }
}