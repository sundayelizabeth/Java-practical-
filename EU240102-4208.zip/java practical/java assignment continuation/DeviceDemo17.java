

interface Switchable {

    void turnOn();

}

interface Rechargeable {

    void charge();

}

class Phone implements Switchable, Rechargeable {

    @Override
    public void turnOn() {
        System.out.println("Phone is turned on.");
    }

    @Override
    public void charge() {
        System.out.println("Phone is charging.");
    }

}

public class DeviceDemo17 {

    public static void main(String[] args) {

        Phone phone = new Phone();

        phone.turnOn();
        phone.charge();

    }

}