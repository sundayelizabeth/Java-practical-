// File: DynamicBinding.java

class Animal {
    public void makeSound() {
        System.out.println("Animal makes a sound.");
    }
}

class Dog extends Animal {
    @Override
    public void makeSound() {
        System.out.println("Dog says: Woof!");
    }
}

class Cat extends Animal {
    @Override
    public void makeSound() {
        System.out.println("Cat says: Meow!");
    }
}

public class DynamicBinding {

    public static void main(String[] args) {
        Animal[] animals = { new Dog(), new Cat(), new Animal() };

        System.out.println("Dynamic binding demo:");
        for (Animal animal : animals) {
            printSound(animal);
        }
    }

    private static void printSound(Animal animal) {
        animal.makeSound();
    }
}