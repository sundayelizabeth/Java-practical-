class car {
    private String model;
    private int speed;

    public car(String model, int speed) {
        this.model = model;
        this.speed = speed;
    }

    public void acceleration(int amount) {
        speed += amount;
    }

    public void brake(int amount) {
        speed -= amount;
        if (speed < 0) {
            speed = 0;
        }
    }

    public void display() {
        System.out.println("Model: " + model);
        System.out.println("Speed: " + speed + " km/h");
    }
}

public class cartest {
    public static void main(String[] args) {
        car car = new car("Toyota camry", 0);

        car.acceleration(50);
        car.display();

        car.brake(20);
        car.display();
    }
}
