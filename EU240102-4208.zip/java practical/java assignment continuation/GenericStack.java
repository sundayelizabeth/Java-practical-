
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.NoSuchElementException;

/**
 * Generic Stack implementation using Deque
 */
public class GenericStack<T> {
    private final Deque<T> data = new ArrayDeque<>();

    public void push(T item) {
        data.push(item);
    }

    public T pop() {
        if (data.isEmpty()) {
            throw new NoSuchElementException("Stack is empty");
        }
        return data.pop();
    }

    public T peek() {
        if (data.isEmpty()) {
            throw new NoSuchElementException("Stack is empty");
        }
        return data.peek();
    }

    public boolean isEmpty() {
        return data.isEmpty();
    }

    public int size() {
        return data.size();
    }

    // Demo (correct usage - no errors)
    public static void main(String[] args) {
        GenericStack<Integer> s = new GenericStack<>();

        s.push(10);
        s.push(20);

        System.out.println("Size: " + s.size());

        System.out.println("Popped: " + s.pop()); // 20
        System.out.println("Peek: " + s.peek());   // 10

        System.out.println("Popped: " + s.pop());  // 10

        // Safe check before popping again
        if (!s.isEmpty()) {
            System.out.println("Popped: " + s.pop());
        } else {
            System.out.println("Stack is empty, cannot pop");
        }

        System.out.println("Is empty now: " + s.isEmpty());
    }
}