import java.io.*;

class student implements Serializable {
    private static final long serialVersionUID = 1L;
    private String name;
    private int age;

    public student(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }
}

public class serializlist {
    public static void main(String[] args) {
        System.out.println("serializlist compiled successfully");
    }
}
