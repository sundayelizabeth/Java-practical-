public class PairTest {
    public static void main(String[] args) {
        Pair<Integer, String> pair = new Pair<>(101, "Teme");

        System.out.println("key: " + pair.getKey());
        System.out.println("value: " + pair.getValue());
    }
}
