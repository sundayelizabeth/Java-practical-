// File: CustomException.java

import java.util.Scanner;

// Custom Exception Class
class InvalidInputException extends Exception {
    public InvalidInputException(String message) {
        super(message);
    }
}

public class CustomException {

    // Method that checks the input
    public static void checkInput(int number) throws InvalidInputException {
        if (number < 0) {
            throw new InvalidInputException("Invalid input! Number cannot be negative.");
        } else {
            System.out.println("Valid input: " + number);
        }
    }

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        try {
            System.out.print("Enter a positive number: ");
            int number = input.nextInt();

            checkInput(number);

        } catch (InvalidInputException e) {
            System.out.println(e.getMessage());
        }

        input.close();
    }
}