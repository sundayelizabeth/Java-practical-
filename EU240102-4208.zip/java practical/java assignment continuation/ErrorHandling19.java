import java.io.*;
import java.util.Scanner;

// Serializable class
class StudentInfo implements Serializable {

    private static final long serialVersionUID = 1L;

    private int id;
    private String name;
    private double score;

    public StudentInfo(int id, String name, double score) {
        this.id = id;
        this.name = name;
        this.score = score;
    }

    @Override
    public String toString() {
        return "ID: " + id +
               "\nName: " + name +
               "\nScore: " + score;
    }
}

public class ErrorHandling19 {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        System.out.print("Enter Student ID: ");
        int id = input.nextInt();
        input.nextLine();

        System.out.print("Enter Student Name: ");
        String name = input.nextLine();

        System.out.print("Enter Student Score: ");
        double score = input.nextDouble();

        StudentInfo student = new StudentInfo(id, name, score);

        // Serialize the object
        try {
            ObjectOutputStream out = new ObjectOutputStream(
                    new FileOutputStream("student.dat"));

            out.writeObject(student);
            out.close();

            System.out.println("\nStudent object saved successfully.");

        } catch (IOException e) {
            System.out.println("Error writing to file: " + e.getMessage());
        }

        // Deserialize the object
        try {
            ObjectInputStream in = new ObjectInputStream(
                    new FileInputStream("student.dat"));

            StudentInfo loadedStudent = (StudentInfo) in.readObject();

            in.close();

            System.out.println("\nStudent object read successfully:");
            System.out.println(loadedStudent);

        } catch (InvalidClassException e) {
            System.out.println("InvalidClassException caught!");
            System.out.println("The class version has changed and cannot be deserialized.");

        } catch (IOException e) {
            System.out.println("File error: " + e.getMessage());

        } catch (ClassNotFoundException e) {
            System.out.println("Class not found: " + e.getMessage());
        }

        input.close();
    }
}