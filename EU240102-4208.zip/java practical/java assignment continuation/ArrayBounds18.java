
import java.util.Scanner;

public class ArrayBounds18 {

    // Method to get an element from the array
    public static int getElement(int[] array, int index) {

        // Assert that the index is within bounds
        assert index >= 0 && index < array.length : "Error: Array index is out of bounds.";

        return array[index];
    }

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        System.out.print("Enter the size of the array: ");
        int size = input.nextInt();

        int[] numbers = new int[size];

        System.out.println("Enter " + size + " array elements:");
        for (int i = 0; i < size; i++) {
            numbers[i] = input.nextInt();
        }

        System.out.print("Enter the index to access: ");
        int index = input.nextInt();

        int value = getElement(numbers, index);

        System.out.println("Element at index " + index + " is: " + value);

        input.close();
    }
}