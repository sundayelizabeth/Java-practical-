public class BankAccount {
    private double balance;
    private String accountNumber;

    public BankAccount (String accountNumber, double initialBalance) {
        this.accountNumber = accountNumber;
        this.balance = initialBalance;
    }

    public void deposit(double amount) {
        if (amount > 0){
            balance += amount;
        }
    }

    public double getBalance() {
        return balance;
    }
}

