import java.util.Arrays;
import java.util.List;

public class ListPrinter {

    public static <T> void printList(List<T> list) {
        for (T element : list) {
            System.out.println(element);
        }
    }

    public static void main(String[] args) {
        List<Integer> numbers = Arrays.asList(1, 2, 3, 4, 5);
        List<String> names = Arrays.asList("Teme", "Destiny", "Ekerefe");

        System.out.println("Integer List:");
        printList(numbers);

        System.out.println("\nString List:");
        printList(names);
    }
}
