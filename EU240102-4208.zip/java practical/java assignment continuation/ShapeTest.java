import java.util.Scanner;

class Circle {
    double radius;

    Circle(double radius) {
        this.radius = radius;
    }
    double area() {
        return 3.142 * radius * radius;
    }
}

class Rectangle {
    double length;
    double width;

    Rectangle(double length, double width) {
        this.length = length;
        this.width = width;
    }
    double area() {
        return length * width;
    }
}

public class ShapeTest {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter circle radius: ");
        double radius = input.nextDouble();

        Circle c = new Circle(radius);

        System.out.println("Circle Area = " + c.area());

        System.out.print("Enter Rectangle length: ");
        double length = input.nextDouble();

        System.out.print("Enter Rectangle width: ");
        double width = input.nextDouble();

        Rectangle r = new Rectangle(length, width);

        System.out.println("Rectangle Area = " + r.area());

    }
}
