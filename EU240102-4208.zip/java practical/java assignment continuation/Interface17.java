interface Drawable {
    void draw();
    default void display() {
        System.out.println("Displaying.........");
    }
}
class Paint implements Drawable {
    @Override
    public void draw() {
        System.out.println("Drawing Circle");
    }
}
public class Interface17 {
    public static void main(String[] args) {
        Drawable paint = new Paint();
        paint.draw();
        paint.display();
    }
}
