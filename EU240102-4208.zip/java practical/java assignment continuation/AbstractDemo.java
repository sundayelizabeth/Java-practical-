abstract class Shape {
    abstract double getArea();
    public void display() {
        System.out.println("This is a shape.");
    }
}

class Circle extends Shape {
    private double radius;
    public Circle(double radius) {
        this.radius = radius;
    }

    @Override
    double getArea() {
        return Math.PI * radius * radius;
    }
}
public class AbstractDemo {
    public static void main(String[] args) {
        Shape shape = new Circle(5.0);
        shape.display();
        System.out.println("Area: " + shape.getArea());
    }
}
