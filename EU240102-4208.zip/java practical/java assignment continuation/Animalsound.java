
// File: Animalsound.java

class Animal {
    public void makeSound() {
        System.out.println("Animal makes a sound.");
    }
}

class Cat extends Animal {
    @Override
    public void makeSound() {
        System.out.println("Cat says: Meow!");
    }
}

class Dog extends Animal {
    @Override
    public void makeSound() {
        System.out.println("Dog says: Woof!");
    }
}

public class Animalsound {
    public static void main(String[] args) {
        Animal animal;

        System.out.println("Cat Sound:");
        animal = new Cat();
        animal.makeSound();

        System.out.println("\nDog Sound:");
        animal = new Dog();
        animal.makeSound();
    }
}