import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

// Student class must implement Serializable
class StudentRecord implements Serializable {

    private static final long serialVersionUID = 1L;

    private int id;
    private String name;

    public StudentRecord(int id, String name) {
        this.id = id;
        this.name = name;
    }

    @Override
    public String toString() {
        return "ID: " + id + ", Name: " + name;
    }
}

public class SerializeList19 {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        ArrayList<StudentRecord> students = new ArrayList<>();

        System.out.print("How many students do you want to enter? ");
        int n = input.nextInt();
        input.nextLine(); // Consume newline

        // Input student records
        for (int i = 0; i < n; i++) {

            System.out.println("\nStudent " + (i + 1));

            System.out.print("Enter ID: ");
            int id = input.nextInt();
            input.nextLine();

            System.out.print("Enter Name: ");
            String name = input.nextLine();

            students.add(new StudentRecord(id, name));
        }

        // Serialize the ArrayList
        try {
            ObjectOutputStream out =
                    new ObjectOutputStream(new FileOutputStream("students.dat"));

            out.writeObject(students);
            out.close();

            System.out.println("\nStudent list saved successfully.");

        } catch (IOException e) {
            System.out.println("Error saving file.");
        }

        // Deserialize the ArrayList
        try {
            ObjectInputStream in =
                    new ObjectInputStream(new FileInputStream("students.dat"));

            ArrayList<StudentRecord> loadedStudents =
                    (ArrayList<StudentRecord>) in.readObject();

            in.close();

            System.out.println("\nStudents read from file:");

            for (StudentRecord student : loadedStudents) {
                System.out.println(student);
            }

        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Error reading file.");
        }

        input.close();
    }
}