
import java.util.Scanner;

public class PositiveNumber18 {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        System.out.print("Enter a number: ");
        int number = input.nextInt();

        // Assert that the number is positive
        assert number > 0 : "Error: The number must be positive.";

        System.out.println("The number is positive.");

        input.close();
    }
}