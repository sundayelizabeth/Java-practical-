import java.util.ArrayList;

public class GenericDemo {
    public static void main(String[] args) {
        ArrayList<String> list = new ArrayList<>();
        list.add("java");
        list.add("Python");
        System.out.println("list: " +list);

        Box<Integer> box = new Box<>();
        box.setItem(42);
        System.out.println("Box item: " + box.getItem());
    }
}
class Box<T>{
    private T item;
    public void setItem(T item) {
        this.item = item;
    }
    public T getItem(){
        return item;
    }
}