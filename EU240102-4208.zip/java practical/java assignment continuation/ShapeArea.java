import java.util.Scanner;

// Shape superclass
class Shape {
    public double getArea() {
        return 0;
    }
}

// Circle subclass
class Circle extends Shape {
    private double radius;

    public Circle(double radius) {
        this.radius = radius;
    }

    @Override
    public double getArea() {
        return Math.PI * radius * radius;
    }
}

// Rectangle subclass
class Rectangle extends Shape {
    private double length;
    private double width;

    public Rectangle(double length, double width) {
        this.length = length;
        this.width = width;
    }

    @Override
    public double getArea() {
        return length * width;
    }
}

// Main class
public class ShapeArea {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        System.out.print("Enter the radius of the circle: ");
        double radius = input.nextDouble();
        Shape circle = new Circle(radius);

        System.out.print("Enter the length of the rectangle: ");
        double length = input.nextDouble();

        System.out.print("Enter the width of the rectangle: ");
        double width = input.nextDouble();
        Shape rectangle = new Rectangle(length, width);

        System.out.println("\n--- Areas ---");
        System.out.printf("Area of Circle: %.2f%n", circle.getArea());
        System.out.printf("Area of Rectangle: %.2f%n", rectangle.getArea());

        input.close();
    }
}