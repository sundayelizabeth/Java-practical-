// Superclass
abstract class Shape {
    abstract double getArea();
}

// Circle subclass
class Circle extends Shape {
    double radius;

    Circle(double radius) {
        this.radius = radius;
    }

    @Override
    double getArea() {
        return Math.PI * radius * radius;
    }
}

// Rectangle subclass
class Rectangle extends Shape {
    double length;
    double width;

    Rectangle(double length, double width) {
        this.length = length;
        this.width = width;
    }

    @Override
    double getArea() {
        return length * width;
    }
}

public class PolyArray {
    public static void main(String[] args) {

        // Polymorphic array
        Shape[] shapes = new Shape[4];

        shapes[0] = new Circle(7);
        shapes[1] = new Rectangle(10, 5);
        shapes[2] = new Circle(3);
        shapes[3] = new Rectangle(6, 2);

        // Loop through array
        for (Shape s : shapes) {
            System.out.println("Area: " + s.getArea());
        }
    }
}