class Vehicle {
    String brand;
    int speed;

    public Vehicle(String brand, int speed) {
        this.brand = brand;
        this.speed = speed;
    }

    public void start() {
        System.out.println(brand + " is starting...");
    }

    public void stop() {
        System.out.println(brand + " has stopped.");
    }

    public void displayInfo() {
        System.out.println("Brand: " + brand + ", Speed: " + speed);
    }
}

// Car subclass
class Car extends Vehicle {
    int doors;

    public Car(String brand, int speed, int doors) {
        super(brand, speed);
        this.doors = doors;
    }

    public void honk() {
        System.out.println(brand + " is honking: Beep Beep!");
    }

    @Override
    public void displayInfo() {
        super.displayInfo();
        System.out.println("Doors: " + doors);
    }
}

// Bicycle subclass
class Bicycle extends Vehicle {
    boolean hasBell;

    public Bicycle(String brand, int speed, boolean hasBell) {
        super(brand, speed);
        this.hasBell = hasBell;
    }

    public void ringBell() {
        if (hasBell) {
            System.out.println(brand + " is ringing the bell: Ring Ring!");
        } else {
            System.out.println(brand + " has no bell.");
        }
    }

    @Override
    public void displayInfo() {
        super.displayInfo();
        System.out.println("Has Bell: " + hasBell);
    }
}

// Main class to test everything
public class Main {
    public static void main(String[] args) {

        Car car = new Car("Toyota", 180, 4);
        Bicycle bike = new Bicycle("Giant", 25, true);

        System.out.println("CAR DETAILS:");
        car.start();
        car.displayInfo();
        car.honk();
        car.stop();

        System.out.println("\nBICYCLE DETAILS:");
        bike.start();
        bike.displayInfo();
        bike.ringBell();
        bike.stop();
    }
}
