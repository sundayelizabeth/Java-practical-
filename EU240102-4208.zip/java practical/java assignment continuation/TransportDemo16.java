// File: TransportSystem.java

abstract class Transport {

    // Abstract method
    abstract void move();

}

class Bus extends Transport {

    @Override
    void move() {
        System.out.println("Bus is carrying passengers.");
    }

}

class Bike extends Transport {

    @Override
    void move() {
        System.out.println("Bike is moving on the road.");
    }

}

public class TransportDemo16 {

    public static void main(String[] args) {

        Transport bus = new Bus();
        Transport bike = new Bike();

        bus.move();
        bike.move();

    }

}