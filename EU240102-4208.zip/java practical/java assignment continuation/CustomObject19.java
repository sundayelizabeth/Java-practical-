import java.io.*;
import java.util.Scanner;

// Custom class
class CrewMember implements Serializable {

    private static final long serialVersionUID = 1L;

    private int id;
    private String name;
    private String department;
    private double salary;

    public CrewMember(int id, String name, String department, double salary) {
        this.id = id;
        this.name = name;
        this.department = department;
        this.salary = salary;
    }

    @Override
    public String toString() {
        return "Crew Member Details"
                + "\nID: " + id
                + "\nName: " + name
                + "\nDepartment: " + department
                + "\nSalary: " + salary;
    }
}

public class CustomObject19 {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        // Get user input
        System.out.print("Enter Crew Member ID: ");
        int id = input.nextInt();
        input.nextLine();

        System.out.print("Enter Crew Member Name: ");
        String name = input.nextLine();

        System.out.print("Enter Department: ");
        String department = input.nextLine();

        System.out.print("Enter Salary: ");
        double salary = input.nextDouble();

        CrewMember crewMember = new CrewMember(id, name, department, salary);

        // Serialize the object
        try {
            ObjectOutputStream out = new ObjectOutputStream(
                    new FileOutputStream("crewmember.dat"));

            out.writeObject(crewMember);
            out.close();

            System.out.println("\nCrew member object saved successfully.");

        } catch (IOException e) {
            System.out.println("Error saving object.");
        }

        // Deserialize the object
        try {
            ObjectInputStream in = new ObjectInputStream(
                    new FileInputStream("crewmember.dat"));

            CrewMember loadedCrewMember = (CrewMember) in.readObject();

            in.close();

            System.out.println("\nCrew member object read from file:");
            System.out.println(loadedCrewMember);

        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Error reading object.");
        }

        input.close();
    }
}