import java.util.Scanner;
class Parent {
    String name;
    int age;

    Parent() {
        this("Default Name", 0);
        System.out.println("Parent no-arg constructor called");
    }

    Parent(String name, int age) {
        this.name = name;
        this.age = age;
        System.out.println("Parent parameterized constructor called");
    }

    void showParentInfo() {
        System.out.println("Name: " + name + ", Age: " + age);
    }
}

// Main class (FILE NAME MUST MATCH THIS)
public class Chaining extends Parent {
    String course;

    // no-arg constructor
    Chaining() {
        super(); // implicitly calls Parent()
        this.course = "Computer Science";
        System.out.println("Chaining no-arg constructor called");
    }

    // parameterized constructor
    Chaining(String name, int age, String course) {
        super(name, age); // calls Parent constructor with parameters
        this.course = course;
        System.out.println("Chaining parameterized constructor called");
    }

    void showInfo() {
        showParentInfo();
        System.out.println("Course: " + course);
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("=== Object 1 ===");
        Chaining obj1 = new Chaining();
        obj1.showInfo();

        System.out.println("\n=== Object 2 ===");
        System.out.print("Enter name: ");
        String name = scanner.nextLine();
        
        System.out.print("Enter age: ");
        int age = scanner.nextInt();
        scanner.nextLine(); // consume newline
        
        System.out.print("Enter course: ");
        String course = scanner.nextLine();
        
        Chaining obj2 = new Chaining(name, age, course);
        obj2.showInfo();
        
        scanner.close();
    }
}