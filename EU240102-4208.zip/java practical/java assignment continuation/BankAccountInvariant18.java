
import java.util.Scanner;

public class BankAccountInvariant18 {

    private int accountNumber;
    private String accountHolder;
    private double balance;

    // Constructor
    public BankAccountInvariant18(int accountNumber, String accountHolder, double balance) {
        this.accountNumber = accountNumber;
        this.accountHolder = accountHolder;
        this.balance = balance;

        checkInvariant();
    }

    // Method to check class invariants
    private void checkInvariant() {
        assert accountNumber > 0 : "Account number must be positive.";
        assert accountHolder != null && !accountHolder.trim().isEmpty()
                : "Account holder name cannot be empty.";
        assert balance >= 0 : "Balance cannot be negative.";
    }

    // Deposit method
    public void deposit(double amount) {
        balance += amount;
        checkInvariant();
    }

    // Withdraw method
    public void withdraw(double amount) {
        balance -= amount;
        checkInvariant();
    }

    // Display account details
    public void display() {
        System.out.println("\n----- Account Details -----");
        System.out.println("Account Number : " + accountNumber);
        System.out.println("Account Holder : " + accountHolder);
        System.out.println("Balance        : ₦" + balance);
    }

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        System.out.print("Enter Account Number: ");
        int accNo = input.nextInt();
        input.nextLine(); // Consume newline

        System.out.print("Enter Account Holder Name: ");
        String name = input.nextLine();

        System.out.print("Enter Initial Balance: ");
        double balance = input.nextDouble();

        BankAccountInvariant18 account =
                new BankAccountInvariant18(accNo, name, balance);

        account.display();

        System.out.println("\n1. Deposit");
        System.out.println("2. Withdraw");
        System.out.print("Choose an option: ");
        int choice = input.nextInt();

        System.out.print("Enter amount: ");
        double amount = input.nextDouble();

        if (choice == 1) {
            account.deposit(amount);
        } else if (choice == 2) {
            account.withdraw(amount);
        } else {
            System.out.println("Invalid choice.");
        }

        account.display();

        input.close();
    }
}