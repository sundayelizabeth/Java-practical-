 import java.util.ArrayList;

public class TypeSafetyDemo {
    public static void main(String[] args) {

        // 1. Non-generic ArrayList (unsafe)
        ArrayList rawList = new ArrayList();

        rawList.add("Hello");
        rawList.add(100); // allowed but unsafe

        System.out.println("RAW LIST:");

        try {
            String a = (String) rawList.get(0);
            System.out.println(a);

            // This will crash at runtime
            String b = (String) rawList.get(1);
            System.out.println(b);

        } catch (ClassCastException e) {
            System.out.println("Error: " + e);
        }

        // 2. Generic ArrayList (safe)
        ArrayList<String> safeList = new ArrayList<>();

        safeList.add("teme ");
        safeList.add("destiny ");
        // safeList.add(100); // compile-time error (commented)

        System.out.print("\nGENERIC LIST:");
        for (String s : safeList) {
            System.out.print(s);
        }
    }
} 
