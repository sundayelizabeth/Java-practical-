class Shape {
    public double getArea() {
        return 0.0;
    }
}


class Circle extends Shape {
    private double radius;
    public Circle(double radius) {
        this.radius = radius;
    }

    @Override
    public double getArea() {
        return Math.PI * radius * radius;
    }
}
public class PolymorphismDemo {
    public static void main(String[] args) {
        Shape shape = new Circle(5.0);
        System.out.println("Area: " + shape.getArea());
    }
}
