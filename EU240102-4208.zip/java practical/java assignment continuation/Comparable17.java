import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Comparable17 implements Comparable<Comparable17> {

    String name;
    int age;

    Comparable17(String name, int age) {
        this.name = name;
        this.age = age;
    }

    @Override
    public int compareTo(Comparable17 other) {
        return this.age - other.age; // Sort by age
    }

    @Override
    public String toString() {
        return name + " - " + age;
    }

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        ArrayList<Comparable17> workers = new ArrayList<>();

        System.out.print("How many workers do you want to enter? ");
        int n = input.nextInt();
        input.nextLine();

        for (int i = 1; i <= n; i++) {
            System.out.println("\nEnter details for Worker " + i);

            System.out.print("Name: ");
            String name = input.nextLine();

            System.out.print("Area of spec: ");
            String areaOfSpec = input.nextLine();

            System.out.print("Age: ");
            int age = input.nextInt();
            input.nextLine();

            workers.add(new Comparable17(name, age));
        }

        Collections.sort(workers);

        System.out.println("\nWorkers sorted by age:");
        for (Comparable17 worker : workers) {
            System.out.println(worker);
        }

        input.close();
    }
}