

abstract class Creature {

    // Abstract method
    abstract void makeSound();

}

class Lion extends Creature {

    @Override
    void makeSound() {
        System.out.println("whoooooooooo!");
    }

}

public class CreatureDemo16 {

    public static void main(String[] args) {

        Creature myCreature = new Lion();
        myCreature.makeSound();

    }

}