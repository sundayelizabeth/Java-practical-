
// File: MultipleCatches.java

import java.util.Scanner;

public class MultipleCatches {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        try {
            System.out.print("Enter the first number: ");
            int num1 = input.nextInt();

            System.out.print("Enter the second number: ");
            int num2 = input.nextInt();

            int result = num1 / num2;
            System.out.println("Result = " + result);

            // This will cause an ArrayIndexOutOfBoundsException
            int[] numbers = {10, 20, 30};
            System.out.println("Fourth element: " + numbers[3]);

        } catch (ArithmeticException e) {
            System.out.println("Error: Cannot divide by zero.");

        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Error: Array index is out of bounds.");

        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }

        input.close();
    }
}