public class Assersion18 {
    public static void main(String[] args) {
        int age = -5;
        assert age >=0 : "Age cannot be negative";
        System.out.println("Age: " + age);
    }
}
