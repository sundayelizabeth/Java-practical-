

interface Greeting {

    // Default method
    default void sayHello() {
        System.out.println("Hello, welcome!");
    }

}

class Student implements Greeting {
    // No need to override the default method
}

public class DefaultMethod17 {

    public static void main(String[] args) {

        Student student = new Student();

        // Calling the default method
        student.sayHello();

    }

}