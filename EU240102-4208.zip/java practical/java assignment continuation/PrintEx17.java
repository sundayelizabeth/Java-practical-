// File: PrintDemo.java

interface Printable {

    void print();

}

class Book implements Printable {

    @Override
    public void print() {
        System.out.println("Printing a book.");
    }

}

class Document implements Printable {

    @Override
    public void print() {
        System.out.println("Printing a document.");
    }

}

public class PrintEx17 {

    public static void main(String[] args) {

        Printable book = new Book();
        Printable document = new Document();

        book.print();
        document.print();

    }

}